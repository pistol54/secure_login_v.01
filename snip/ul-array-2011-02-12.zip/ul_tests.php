<?php
$ul_str = '
<ul>
    <li>Accesorii
        <ul>
            <li>Portbagaj / Locas incarcare</li>
        </ul>
    </li>
    <li>Ambreiaj/ Piese
        <ul>
            <li>Comanda ambreiaj
                <ul>
                    <li>Cilindru receptor</li>
                    <li>Pompa ambreiaj</li>
                </ul>
            </li>
            <li>Disc ambreiaj</li>
            <li>Placa de presiune ambreiaj</li>
            <li>Set reparatie ambreiaj complet</li>
        </ul>
    </li>
    <li>Angrenare roata
        <ul>
            <li>Articulatie/ Set</li>
            <li>Burduf</li>
            <li>Planetara</li>
        </ul>
    </li>
    <li>Aprindere scanteie/incandescenta
        <ul>
            <li>Bobina inductie</li>
            <li>Bujie</li>
            <li>Generator impulsuri</li>
            <li>Modul aprindere</li>
            <li>Unitate de control / Relee/Senzori</li>
        </ul>
    </li>
    <li>Caroserie
        <ul>
            <li>Amorizoare vibratii pe gaz</li>
            <li>Celula pasager
                <ul>
                    <li>Elemente/Piese montaj
                        <ul>
                            <li>Amorizoare vibratii pe gaz</li>
                        </ul>
                    </li>
                    <li>Oglinzi</li>
                    <li>Stop frana aditional</li>
                    <li>Usi/piese</li>
                </ul>
            </li>
            <li>Elemente caroserie/Aripa/Bara protectie
                <ul>
                    <li>Acoperire spate</li>
                    <li>Bara protectie/piese</li>
                    <li>Partea frontala/Grila radiator</li>
                </ul>
            </li>
            <li>Faruri / piese componente
                <ul>
                    <li>Bec cu incendescenta far</li>
                    <li>Far/Insertie</li>
                </ul>
            </li>
            <li>Fata vehicul
                <ul>
                    <li>Bara protectie/piese</li>
                    <li>Far ceata / Elemente
                        <ul>
                            <li>Bec far  ceata</li>
                            <li>Proiector ceata / Montare</li>
                        </ul>
                    </li>
                    <li>Faruri / piese componente
                        <ul>
                            <li>Bec cu incendescenta far</li>
                            <li>Far/Insertie</li>
                        </ul>
                    </li>
                    <li>Iluminare de pozitie/Demarcare/Piese
                        <ul>
                            <li>Bec</li>
                            <li>Lumini de demarcare</li>
                            <li>Lumini pozitie</li>
                        </ul>
                    </li>
                    <li>Proiectoare / Elemente
                        <ul>
                            <li>Bec far faza lunga</li>
                        </ul>
                    </li>
                    <li>Semnalizare / elemente
                        <ul>
                            <li>Bec, semnalizare</li>
                            <li>Semnalizare</li>
                        </ul>
                    </li>
                </ul>
            </li>
            <li>Geamuri/Oglinzi
                <ul>
                    <li>Oglinzi</li>
                </ul>
            </li>
            <li>Iluminari auxiliare / Elemente
                <ul>
                    <li>Far ceata / Elemente
                        <ul>
                            <li>Bec far  ceata</li>
                            <li>Proiector ceata / Montare</li>
                        </ul>
                    </li>
                    <li>Proiectoare / Elemente
                        <ul>
                            <li>Bec far faza lunga</li>
                        </ul>
                    </li>
                </ul>
            </li>
            <li>Lumini
                <ul>
                    <li>Bec numar inmatriculare
                        <ul>
                            <li>Bec, iluminare numar inmatriculare</li>
                        </ul>
                    </li>
                    <li>Iluminare de pozitie/Demarcare/Piese
                        <ul>
                            <li>Bec</li>
                            <li>Lumini de demarcare</li>
                            <li>Lumini pozitie</li>
                        </ul>
                    </li>
                    <li>Lampa spate/ Piese
                        <ul>
                            <li>Bec, lampa spate</li>
                        </ul>
                    </li>
                    <li>Lumini ceata spate / Elemente
                        <ul>
                            <li>Bec, lampa ceata spate</li>
                        </ul>
                    </li>
                    <li>Lumini frana / elemente
                        <ul>
                            <li>Bec, lampa stop</li>
                            <li>Stop frana aditional</li>
                        </ul>
                    </li>
                    <li>Lumini mers inapoi / Elemente
                        <ul>
                            <li>Bec, lampa mers inapoi</li>
                        </ul>
                    </li>
                    <li>Lumini portiera</li>
                    <li>Semnalizare / elemente
                        <ul>
                            <li>Bec, semnalizare</li>
                            <li>Lumina semnalizare laterala</li>
                            <li>Semnalizare</li>
                        </ul>
                    </li>
                    <li>Stopuri / Elemente
                        <ul>
                            <li>Stopuri</li>
                        </ul>
                    </li>
                </ul>
            </li>
            <li>Spate vehicul
                <ul>
                    <li>Bec numar inmatriculare
                        <ul>
                            <li>Bec, iluminare numar inmatriculare</li>
                        </ul>
                    </li>
                    <li>Elemente/Piese montaj
                        <ul>
                            <li>Amorizoare vibratii pe gaz</li>
                        </ul>
                    </li>
                    <li>Iluminare de pozitie/Demarcare/Piese
                        <ul>
                            <li>Bec</li>
                            <li>Lumini de demarcare</li>
                            <li>Lumini pozitie</li>
                        </ul>
                    </li>
                    <li>Lampa spate/ Piese
                        <ul>
                            <li>Bec, lampa spate</li>
                        </ul>
                    </li>
                    <li>Lumini ceata spate / Elemente
                        <ul>
                            <li>Bec, lampa ceata spate</li>
                        </ul>
                    </li>
                    <li>Lumini frana / elemente
                        <ul>
                            <li>Bec, lampa stop</li>
                            <li>Stop frana aditional</li>
                        </ul>
                    </li>
                    <li>Lumini mers inapoi / Elemente
                        <ul>
                            <li>Bec, lampa mers inapoi</li>
                        </ul>
                    </li>
                    <li>Semnalizare / elemente
                        <ul>
                            <li>Bec, semnalizare</li>
                            <li>Semnalizare</li>
                        </ul>
                    </li>
                    <li>Stopuri / Elemente
                        <ul>
                            <li>Stopuri</li>
                        </ul>
                    </li>
                </ul>
            </li>
            <li>trapa/ capota/ usi/ acoperis escamotabil/ pavilion pliant
                <ul>
                    <li>Usi/piese</li>
                </ul>
            </li>
        </ul>
    </li>
    <li>Curea distributie
        <ul>
            <li>Curea distributie/ Set
                <ul>
                    <li>Curea distributie</li>
                    <li>Rola intinzatoare</li>
                    <li>Set curea distributie</li>
                    <li>Set role</li>
                </ul>
            </li>
            <li>Curea transmisie cu caneluri/ Set
                <ul>
                    <li>Curea transmisie cu caneluri</li>
                </ul>
            </li>
            <li>Curea trapezoidala/ Set
                <ul>
                    <li>Curea de transmisie trapezoidala</li>
                </ul>
            </li>
        </ul>
    </li>
    <li>Cutie de viteze
        <ul>
            <li>Cutie de viteze manuala
                <ul>
                    <li>Uleiuri</li>
                </ul>
            </li>
        </ul>
    </li>
    <li>Directie
        <ul>
            <li>Articulatii directie</li>
            <li>Bieleta directie/ Piese
                <ul>
                    <li>Bielete directie</li>
                    <li>Piese, bielete directie</li>
                </ul>
            </li>
            <li>Burduf/Garnitura</li>
            <li>Caseta directie/ Pompa servodirectie</li>
            <li>Legaturi directie</li>
            <li>Uleiuri</li>
        </ul>
    </li>
    <li>Echipament interior
        <ul>
            <li>mecanism cu parghii manual/de picior</li>
            <li>Portbagaj</li>
        </ul>
    </li>
    <li>Electrice
        <ul>
            <li>Acumulator</li>
            <li>Faruri / piese componente
                <ul>
                    <li>Bec cu incendescenta far</li>
                    <li>Far/Insertie</li>
                </ul>
            </li>
            <li>Generator /Alternator / Elemente
                <ul>
                    <li>Alternator</li>
                    <li>Rgulator tensiune</li>
                </ul>
            </li>
            <li>Iluminari auxiliare / Elemente
                <ul>
                    <li>Far ceata / Elemente
                        <ul>
                            <li>Bec far  ceata</li>
                            <li>Proiector ceata / Montare</li>
                        </ul>
                    </li>
                    <li>Far pentru viraj/repere</li>
                    <li>Proiectoare / Elemente
                        <ul>
                            <li>Bec far faza lunga</li>
                        </ul>
                    </li>
                </ul>
            </li>
            <li>Indicatoare
                <ul>
                    <li>Senzori / Traductori (senzori)</li>
                </ul>
            </li>
            <li>Intrerupatoare / Relee / Control
                <ul>
                    <li>Intrerupator / Regulator</li>
                </ul>
            </li>
            <li>Lumini
                <ul>
                    <li>Bec numar inmatriculare
                        <ul>
                            <li>Bec, iluminare numar inmatriculare</li>
                        </ul>
                    </li>
                    <li>Iluminare de pozitie/Demarcare/Piese
                        <ul>
                            <li>Bec</li>
                            <li>Lumini de demarcare</li>
                            <li>Lumini pozitie</li>
                        </ul>
                    </li>
                    <li>Iluminare interior
                        <ul>
                            <li>Iluminare habitaclu</li>
                            <li>Iluminare motor</li>
                            <li>Iluminare portbagaj</li>
                            <li>Iluminare torpedou</li>
                            <li>Lumina de citit</li>
                        </ul>
                    </li>
                    <li>Lumini ceata spate / Elemente
                        <ul>
                            <li>Bec, lampa ceata spate</li>
                        </ul>
                    </li>
                    <li>Lumini de zi</li>
                    <li>Lumini frana / elemente
                        <ul>
                            <li>Bec, lampa stop</li>
                            <li>Stop frana aditional</li>
                        </ul>
                    </li>
                    <li>Lumini mers inapoi / Elemente
                        <ul>
                            <li>Bec, lampa mers inapoi</li>
                        </ul>
                    </li>
                    <li>Lumini portiera</li>
                    <li>Semnalizare / elemente
                        <ul>
                            <li>Bec, semnalizare</li>
                            <li>Semnalizare</li>
                        </ul>
                    </li>
                    <li>Stopuri / Elemente
                        <ul>
                            <li>Bec incandescent, stopuri</li>
                            <li>Stopuri</li>
                        </ul>
                    </li>
                </ul>
            </li>
            <li>Relee</li>
            <li>Senzor</li>
            <li>Sistem pornire
                <ul>
                    <li>Electromotor</li>
                </ul>
            </li>
            <li>Sistem semnalizare / Releu</li>
        </ul>
    </li>
    <li>Filtre
        <ul>
            <li>Filtru aer</li>
            <li>Filtru combustibil</li>
            <li>Filtru habitaclu</li>
            <li>Filtru ulei</li>
        </ul>
    </li>
    <li>Incalzire
        <ul>
            <li>Filtru aer habitaclu</li>
            <li>Motor ventilator/Piese</li>
            <li>Schimbator caldura</li>
        </ul>
    </li>
    <li>Motor
        <ul>
            <li>Admisie aer motor
                <ul>
                    <li>Clapeta / - sensor
                        <ul>
                            <li>Senzor clapeta</li>
                        </ul>
                    </li>
                    <li>Filtru aer/ Carcasa</li>
                    <li>Reglare compressor</li>
                </ul>
            </li>
            <li>Chiuloasa/piese
                <ul>
                    <li>Chiuloasa</li>
                    <li>Garnitura /capac supape</li>
                    <li>Garnitura chiuloasa</li>
                    <li>Ghid supapa/Simering supapa/reglaj supapa</li>
                    <li>Simering arbore cotit / ax cu came</li>
                </ul>
            </li>
            <li>Control distributie
                <ul>
                    <li>ax cu came</li>
                    <li>Curea distributie / Rola de tensionare / Rola de ghidare
                        <ul>
                            <li>Curea de distributie</li>
                            <li>Rola de tensionare</li>
                            <li>Set curea de distributie</li>
                            <li>Set role</li>
                        </ul>
                    </li>
                    <li>Supapa/ -reglare
                        <ul>
                            <li>Ansamblu culbutori</li>
                            <li>Supapa / accesorii</li>
                        </ul>
                    </li>
                </ul>
            </li>
            <li>Control gaze evacuare
                <ul>
                    <li>Sonda lambda</li>
                </ul>
            </li>
            <li>Electricitate motor</li>
            <li>Garnituri
                <ul>
                    <li>Garnitura capac supape</li>
                    <li>Garnitura chiuloasa</li>
                    <li>Simering arbore/ -set</li>
                    <li>Simering supapa</li>
                </ul>
            </li>
            <li>Suport motor
                <ul>
                    <li>Suport motor</li>
                </ul>
            </li>
            <li>Ungere
                <ul>
                    <li>Comutator presiune ulei / Senzor / Supapa</li>
                    <li>Filtru ulei</li>
                    <li>Uleiuri</li>
                </ul>
            </li>
        </ul>
    </li>
    <li>Piese de service/ Inspectie / Intretinere
        <ul>
            <li>Intervale de service</li>
            <li>Reparatii aditionale</li>
        </ul>
    </li>
    <li>Sistem alimentare combustibil
        <ul>
            <li>Amortizor pulsatii</li>
            <li>Filtru combustibil/Carcasa</li>
            <li>Regulator presiune combustibil/ Intrerupator</li>
            <li>Rezervor combustibil/ Piese</li>
        </ul>
    </li>
    <li>Sistem curatare parbriz
        <ul>
            <li>Pompa apa sistem curatire parbriz</li>
            <li>Stergator de parbriz</li>
        </ul>
    </li>
    <li>Sistem de aer conditionat
        <ul>
            <li>Compresor/Piese</li>
            <li>Intrerupator</li>
            <li>Radiator clima</li>
            <li>Supape</li>
            <li>Uscator</li>
            <li>Vaporizator</li>
        </ul>
    </li>
    <li>Sistem de formare a amestecului
        <ul>
            <li>Control emisie gaze de esapament
                <ul>
                    <li>Control Lambda</li>
                </ul>
            </li>
            <li>Pregatire amestec
                <ul>
                    <li>Control mers in gol</li>
                    <li>injector / duza injectie / tija injector</li>
                    <li>Senzor / Sonda</li>
                </ul>
            </li>
        </ul>
    </li>
    <li>Sistem de franare
        <ul>
            <li>Cilindru receptor frana</li>
            <li>Comutator lumini frana</li>
            <li>Control al dinamicii de rulare</li>
            <li>Etrier
                <ul>
                    <li>Suport etrier</li>
                </ul>
            </li>
            <li>Frana disc
                <ul>
                    <li>Componente/ Accesorii frana</li>
                    <li>Disc frana</li>
                    <li>Set placute frana</li>
                </ul>
            </li>
            <li>Frana tambur
                <ul>
                    <li>Cilindru receptor frana</li>
                    <li>Material frictiune sabot frana/ Sabot frana</li>
                    <li>Piese disc tambur</li>
                    <li>Tambur frana</li>
                </ul>
            </li>
            <li>Furtun frana</li>
            <li>Maneta/ cablu</li>
            <li>Pompa centrala frana</li>
            <li>Regulator forta de frana</li>
        </ul>
    </li>
    <li>Sistem de racire motor
        <ul>
            <li>Comutator / senzor</li>
            <li>Pompa apa/ Garnitura
                <ul>
                    <li>Pompa apa</li>
                </ul>
            </li>
            <li>Radiator racire apa/ ulei
                <ul>
                    <li>Radiator apa/Piese</li>
                    <li>Radiator incalzire interior</li>
                </ul>
            </li>
            <li>Termostat/ Garnitura
                <ul>
                    <li>Termostat</li>
                </ul>
            </li>
        </ul>
    </li>
    <li>Sistemul de esapament
        <ul>
            <li>Catalizator</li>
            <li>Sistem de evacuare, complet</li>
            <li>Sonda Lambda</li>
            <li>Toba de esapament</li>
        </ul>
    </li>
    <li>Suspensie
        <ul>
            <li>Amortizor</li>
            <li>Arc spirala</li>
            <li>Elemente suspensie
                <ul>
                    <li>Piese componente</li>
                </ul>
            </li>
            <li>Rulment sarcina</li>
        </ul>
    </li>
    <li>Suspensie/directie/roti
        <ul>
            <li>Butuc roata /-lagar
                <ul>
                    <li>Prezon roata</li>
                    <li>Rulment roata</li>
                </ul>
            </li>
            <li>Directie / bucsi, rulmenti
                <ul>
                    <li>elemente directie(bieleta directie, antiruliu,cap bara)</li>
                    <li>Lagar/Fixare</li>
                </ul>
            </li>
            <li>Stabilizare / Rigidizare
                <ul>
                    <li>bara torsiune</li>
                    <li>Bieleta antiruliu</li>
                    <li>Rigidizari</li>
                </ul>
            </li>
            <li>Suport ansamblu amortizor-arc</li>
        </ul>
    </li>
</ul>
';


$ul_str2="
<ul>
    <li>Test
        <ul>
            <li>Test1
                <ul>
                    <li>Test1.1</li>
                    <li>Test1.2
                        <ul>
                            <li>Test1.2.1</li>
                            <li>Test1.2.2</li>
                            <li>Test1.2.3</li>
                        </ul>
                    </li>
                    <li>Test 1.3</li>
                    <li>Test 1.4</li>
                    <li>Test 1.5
                        <ul>
                            <li>Test1.5.1</li>
                            <li>Test1.5.2</li>
                            <li>Test1.5.3
                                <ul>
                                    <li>Test1.5.3.1</li>
                                    <li>Test1.5.3.2</li>
                                    <li>Test1.5.3.3</li>
                                </ul>
                            </li>
                        </ul>
                    </li>
                    <li>Test 1.6</li>
                    <li>Test 1.6
                        <ul>
                            <li>Test1.6.1 dublura</li>
                        </ul>
                    </li>
                    <li>Test 1.6
                        <ul>
                            <li>Test1.6.1 xx</li>
                        </ul>
                    </li>
                </ul>
            </li>
        </ul>
    </li>
    <li>Test4
        <ul>
            <li>Test4.1
                <ul>
                    <li>Test4.1.1</li>
                </ul>
            </li>
            <li>Test4.2
                <ul>
                    <li>Test4.2.1</li>
                </ul>
            </li>
            <li>Test4.3
                <ul>
                    <li>Test4.3.1
                        <ul>
                            <li>Test4.3.1.1
                                <ul>
                                    <li>Test4.3.1.1.1</li>
                                </ul>
                            </li>
                        </ul>
                    </li>
                    <li>Test4.3.2</li>
                </ul>
            </li>
        </ul>
    </li>
</ul>";

$ul_str3 =
'
<ul>
    <li>Accesorii
        <ul>
            <li>Portbagaj / Locas incarcare</li>
        </ul>
    </li>
    <li>Ambreiaj/ Piese
        <ul>
            <li>Comanda ambreiaj
                <ul>
                    <li>Cilindru receptor</li>
                    <li>Pompa ambreiaj</li>
                </ul>
            </li>
            <li>Disc ambreiaj</li>
            <li>Placa de presiune ambreiaj</li>
            <li>Set reparatie ambreiaj complet</li>
        </ul>
    </li>
</ul>
';
?>
